/** View of solid cube (each face a solid color).
 *
 *  @author N. Danner
 */

#include <assert.h>
#include <float.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef __MACOSX__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#elif defined __LINUX__ || defined __CYGWIN__
#define GL_GLEXT_PROTOTYPES
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#endif

#include "geom356.h"
#include "list356.h"

#include "maze.h"

// A marginally-clever debugging function that expends to a no-op
// when NDEBUG is defined and otherwise prints its string formatting
// arguments to stderr.
#ifdef NDEBUG
#define debug(fmt, ...) 
#define debug_c(expr, fmt, ...)
#else
#include <stdarg.h>
void debug(const char* fmt, ...) {
    va_list argptr ;
    va_start(argptr, fmt) ;

    char* fmt_newline ;
    asprintf(&fmt_newline, "%s\n", fmt) ;
    vfprintf(stderr, fmt_newline, argptr) ;
    free(fmt_newline) ;
    fflush(stderr) ;
}
void debug_c(bool expr, const char* fmt, ...) {
    if (expr) {
        va_list argptr ;
        va_start(argptr, fmt) ;

        char* fmt_newline ;
        asprintf(&fmt_newline, "%s\n", fmt) ;
        vfprintf(stderr, fmt_newline, argptr) ;
        free(fmt_newline) ;
        fflush(stderr) ;
    }
}
#endif

// Window data.
const int DEFAULT_WIN_WIDTH = 800 ;
const int DEFAULT_WIN_HEIGHT = 600 ;
int win_width ;
int win_height ;

// Viewing data.
// Eye is located distance eye_r from origin; angle eye_theta from +x axis
// in xz-plane; angle eye_phi from xz-plane.
float eye_x, eye_y, eye_z ;
float heading ; // Angle with +x axis.  In degrees!
#define HEADING_INCR 5.0
#define STEP_DIST .1
#define BOUNDING_RADIUS .1
#define JUMP_HEIGHT 20

// View-volume specification in camera frame basis.
float view_plane_near = 0.01f ; // Very close to the eye, so that it stays
                                // inside our bounding sphere.
float view_plane_far = FLT_MAX ; 

// Callbacks.
void handle_display(void) ;
void handle_resize(int, int) ;
void handle_key(unsigned char, int, int) ;
void handle_special_key(int, int, int) ;

// Display list data.
GLuint maze_list ;
void make_maze_list(GLuint) ;

// Application functions.
void init() ;

// Application data.
maze_t* maze ;
int nrows, ncols ;
bool am_jumping ;
list356_t* visited ;
#define WALL_WIDTH .25
#define WALL_WIDTH2 WALL_WIDTH/2.0

// Materials and lights.  Note that colors are RGBA colors.  OpenGL lights
// have diffuse, specular, and ambient components; we'll default to setting
// the first two equal to each other and the OpenGL default for ambient
// (black).  And the position is in homogeneous coordinates, so a w-value
// of 0 means "infinitely far away," whereas a w-value of 1 means the position
// is a point in the world.

// Lighting.
typedef struct _light_t {
    GLfloat position[4] ;
    GLfloat color[4] ;
} light_t ;

GLfloat BLACK[4] = {0.0, 0.0, 0.0, 1.0} ;
GLfloat light0_pos[4] = {0.0, 0.0, 0.0, 1.0} ; // To be set in init().
GLfloat light1_pos[4] = {0.0, 0.0, 0.0, 1.0} ; // To be set in init().
GLfloat light_color[4] = {0.5, 0.5, 0.5, 1.0} ;
/*
light_t light0 = {
    {30.0, -10.0, 50.0, 1.0},
    {0.75, 0.75, 0.75, 1.0}
} ;
*/

// Materials.
typedef struct _material_t {
    GLfloat ambient[4] ;
    GLfloat diffuse[4] ;
    GLfloat specular[4] ;
    GLfloat phong_exp ;
} material_t ;

material_t gold = {
    {.10f, .084f, 0.0f, 1.0f},
    {1.0f, .84f, 0.0f, 1.0f},
    {1.0f, 1.0f, 1.0f, 1.0f},
    100.0f
} ;

material_t red_plastic = {
    {1.0f, 0.0f, 0.0f, 1.0f},
    {1.0f, 0.0f, 0.0f, 1.0f},
    {1.0f, 1.0f, 1.0f, 1.0f},
    100.0f
} ;

material_t green_plastic = {
    {0.0f, 1.0f, 0.0f, 1.0f},
    {0.0f, 1.0f, 0.0f, 1.0f},
    {1.0f, 1.0f, 1.0f, 1.0f},
    // {0.0f, 0.0f, 0.0f, 1.0f},
    100.0f
} ;

material_t blue_plastic = {
    {0.0f, 0.0f, 1.0f, 1.0f},
    {0.0f, 0.0f, 1.0f, 1.0f},
    {1.0f, 1.0f, 1.0f, 1.0f},
    100.0f
} ;

int main(int argc, char **argv) {

    // Initialize the drawing window.
    glutInitWindowSize(DEFAULT_WIN_WIDTH, DEFAULT_WIN_HEIGHT) ;
    glutInitWindowPosition(0, 0) ;
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH ) ;
    glutInit(&argc, argv) ;

    // Parse our command-line arguments.
    nrows = atoi(argv[1]) ;
    ncols = atoi(argv[2]) ;

    // Create the main window.
    debug("Creating window") ;
    glutCreateWindow("Geometry example") ;

    debug("Setting callbacks") ;
    glutReshapeFunc(handle_resize) ;
    glutKeyboardFunc(handle_key) ;
    glutSpecialFunc(handle_special_key) ;
    glutDisplayFunc(handle_display) ;

    // GL initialization.
    glEnable(GL_DEPTH_TEST) ;
    glEnable(GL_CULL_FACE) ;
    glCullFace(GL_BACK) ;
    glEnable(GL_LIGHTING) ;
    glEnable(GL_LIGHT0) ;
    glEnable(GL_LIGHT1) ;
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, 1) ;
    glEnable(GL_NORMALIZE) ;
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f) ;

    // Application initialization.
    init(nrows, ncols) ;
    maze_list = glGenLists(1) ;
    make_maze_list(maze_list) ;

    // Enter the main event loop.
    debug("Main loop") ;
    glutMainLoop() ;

    return EXIT_SUCCESS ;
}

/** Set the camera transformation.  Viewpoint is given by the eye
 *  coordinates; we look at the origin with up-direction along the
 *  +y axis.
 */
void set_camera() {
    debug("set_camera()") ;

    // Set the model-view (i.e., camera) transform.
    glMatrixMode(GL_MODELVIEW) ;
    glLoadIdentity() ;

    // Default world frame is looking along -z axis; we rotate so that
    // we are looking along +x axis (two 90-degree rotations), then rotate 
    // again corresponding to our heading angle.
    glRotatef(-heading, 0, 1, 0) ;
    glRotatef(90, -1, 0, 0) ;
    glRotatef(90, 0, 0, 1) ;
    glTranslatef(-eye_x, -eye_y, -.75) ;
}

/** Set the projection and viewport transformations.  We use perspective
 *  projection and always match the aspect ratio of the screen window
 *  with vertical field-of-view 60 degrees and always map to the entire
 *  screen window.
 */
void set_projection_viewport() {
    debug("set_projection_viewport()") ;

    // Set perspective projection transform.
    glMatrixMode(GL_PROJECTION) ;
    glLoadIdentity() ;
    gluPerspective(60.0, (GLdouble)win_width/win_height, view_plane_near, 
            view_plane_far) ;

    // Set the viewport transform.
    glViewport(0, 0, win_width, win_height) ;
}

/** Configure the light(s).  Since the position of the light
 *  is subject to the current model-view transform, and we want
 *  the light to be fixed to the world (not the viewer),
 *  we don't set the position until we draw the scene.
 */
void set_lights() {
    debug("set_lights()") ;

    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_color) ;
    glLightfv(GL_LIGHT0, GL_AMBIENT, BLACK) ;
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_color) ;
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light_color) ;
    glLightfv(GL_LIGHT1, GL_AMBIENT, BLACK) ;
    glLightfv(GL_LIGHT1, GL_SPECULAR, light_color) ;
}

/** Application initialization.  Create the maze, initialize the visited
 *  list to be empty, set the light(s) and camera.
 *
 *  @param nrows the number of rows in the maze.
 *  @param ncols the number of columns in the maze.
 */
void init(int nrows, int ncols) {
    debug("init") ;

    // Create the maze.
    maze = make_maze(nrows, ncols, time(NULL)) ;
    debug("init():  start, end = (%d, %d), (%d, %d)",
            get_start(maze)->r, get_start(maze)->c,
            get_end(maze)->r, get_end(maze)->c) ;

    am_jumping = false ;

    // Viewpoint position.
    cell_t* start = get_start(maze) ;
    eye_x = start->c ;
    eye_y = start->r ;
    eye_z = .75 ;
    heading = 0.0 ;

    visited = make_list() ;
    lst_add(visited, start) ;


    // Set the lights.
    light0_pos[0] = ncols ;
    light0_pos[1] = 0 ;
    light0_pos[2] = 10 ;
    light0_pos[3] = 1.0 ;

    light1_pos[0] = 0 ;
    light1_pos[1] = nrows ;
    light1_pos[2] = 10 ;
    light1_pos[3] = 1.0 ;

    set_lights() ;

    // Set the viewpoint.
    set_camera() ;
}

/** Handle a resize event by recording the new width and height.
 *  
 *  @param width the new width of the window.
 *  @param height the new height of the window.
 */
void handle_resize(int width, int height) {
    debug("handle_resize(%d, %d)\n", width, height) ;

    win_width = width ;
    win_height = height ;

    set_projection_viewport() ;

    glutPostRedisplay() ;
}

//
// RENDERING FUNCTIONS
//

/** Draw a single cube, which is the rectangular solid
 *  [0, 1] x [-.5, .5] x [0, 1].  We don't bother with drawing
 *  the bottom.
 */
void draw_cube() {
    // debug("draw_cube()") ;

    glBegin(GL_QUADS) ;

    // South face.
    glNormal3f(0.0, -1.0, 0.0) ;
    glVertex3f(0, -0.5, 0) ;
    glVertex3f(1.0, -0.5, 0) ;
    glVertex3f(1.0, -0.5, 1) ;
    glVertex3f(0, -0.5, 1) ;

    // East face.
    glNormal3f(1.0, 0.0, 0.0) ;
    glVertex3f(1.0, -0.5, 0) ;
    glVertex3f(1.0, 0.5, 0) ;
    glVertex3f(1.0, 0.5, 1) ;
    glVertex3f(1.0, -0.5, 1) ;

    // North face.
    glNormal3f(0.0, 1.0, 0.0) ;
    glVertex3f(0, 0.5, 0) ;
    glVertex3f(0, 0.5, 1) ;
    glVertex3f(1.0, 0.5, 1) ;
    glVertex3f(1.0, 0.5, 0) ;

    // West face.
    glNormal3f(-1.0, 0.0, 0.0) ;
    glVertex3f(0, 0.5, 0) ;
    glVertex3f(0, -0.5, 0) ;
    glVertex3f(0, -0.5, 1) ;
    glVertex3f(0, 0.5, 1) ;

    // Top.
    glNormal3f(0.0, 0.0, 1.0) ;
    glVertex3f(0, -0.5, 1) ;
    glVertex3f(1.0, -0.5, 1) ;
    glVertex3f(1.0, 0.5, 1) ;
    glVertex3f(0, 0.5, 1) ;

    glEnd() ;
}

/** Draw a floor tile with the given material.
 *  
 *  @param mat the material for the floor tile.
 */
void draw_floor_tile(material_t* mat) {
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat->diffuse) ;
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat->specular) ;
    glMaterialf(GL_FRONT, GL_SHININESS, mat->phong_exp) ;

    glBegin(GL_QUADS) ;
    glNormal3f(0, 0, 1) ;
    glVertex3f(-1, -1, 0) ;
    glVertex3f(1, -1, 0) ;
    glVertex3f(1, 1, 0) ;
    glVertex3f(-1, 1, 0) ;
    glEnd() ;
}

/** Make the display list for the maze.  This function creates an
 *  OpenGL *display list*, which is essentially a list of compiled
 *  GL commands to be executed at a later time (via glCallList()).
 *  The idea is that when make_maze_list() is invoked, all of the
 *  instructions will be executed, but only the GL instructions will
 *  be recorded as a compiled program on the GPU.  The point is that
 *  the GL instructions will be recorded with their actual values.
 *  The upshot is that when we make the display list, we do all the
 *  computation necessary to determine where to draw walls; but when
 *  the display list is actually executed, that computation is already
 *  done, and only the GL commands with "hard-coded" arguments are
 *  executed.  This can also speed up display in some cases, because
 *  the display list can be stored on the GPU, thereby avoiding the
 *  overhead of pushing primitives and state changes from main memory
 *  to the GPU.
 *
 *  @param list_id the display list id.
 */
void make_maze_list(GLuint list_id) {
    debug("make_maze_list(%d)", list_id) ;

    glNewList(list_id, GL_COMPILE) ;

    glMatrixMode(GL_MODELVIEW) ;

    cell_t* start = get_start(maze) ;
    glPushMatrix() ;
    glTranslatef(start->c, start->r, 0) ;
    glScalef(.5, .5, 1) ;
    draw_floor_tile(&green_plastic) ;
    glPopMatrix() ;

    cell_t* end = get_end(maze) ;
    glPushMatrix() ;
    glTranslatef(end->c, end->r, 0) ;
    glScalef(.5, .5, 1) ;
    draw_floor_tile(&red_plastic) ;
    glPopMatrix() ;

    debug("make_maze_list(): wall material.") ;
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, blue_plastic.diffuse) ;
    glMaterialfv(GL_FRONT, GL_SPECULAR, blue_plastic.specular) ;
    glMaterialf(GL_FRONT, GL_SHININESS, blue_plastic.phong_exp) ;

    // South wall.
    glPushMatrix() ;
    glTranslatef(-.5+WALL_WIDTH2, -.5, 0) ;
    glScalef(ncols, WALL_WIDTH, 1) ;
    draw_cube() ;
    glPopMatrix() ;

    // West wall.
    glPushMatrix() ;
    glTranslatef(-.5, -.5+WALL_WIDTH2, 0) ;
    glScalef(WALL_WIDTH, nrows, 1) ;
    glRotatef(90, 0, 0, 1) ;
    draw_cube() ;
    glPopMatrix() ;


    debug("make_maze_list(): walls.") ;
    for (int r=0; r<=nrows; ++r) {
        for (int c=0; c<=ncols; ++c) {
            // North wall.
            if (r < nrows && c < ncols && 
                    has_wall(maze, get_cell(maze, r, c), NORTH)) {
                glPushMatrix() ;
                glTranslatef(c-.5+WALL_WIDTH2, r+.5, 0) ;
                glScalef(.75, WALL_WIDTH, 1) ;
                draw_cube() ;
                glPopMatrix() ;
            }
            // East wall.
            if (r < nrows && c < ncols && 
                    has_wall(maze, get_cell(maze, r, c), EAST)) {
                glPushMatrix() ;
                glTranslatef(c+.5, r-.5+WALL_WIDTH2, 0) ;
                glScalef(WALL_WIDTH, .75, 1) ;
                glRotatef(90, 0, 0, 1) ;
                draw_cube() ;
                glPopMatrix() ;
            }
            // Corner post, making use of Nathaniel's observation
            // that Prim's algorithm guarantees that there will be
            // at least one wall at every intersection.
            glPushMatrix() ;
            glTranslatef(c-.5-WALL_WIDTH2, r-.5-WALL_WIDTH2, 0) ;
            glScalef(WALL_WIDTH, WALL_WIDTH, 1) ;
            glTranslatef(0, .5, 0) ;
            draw_cube() ;
            glPopMatrix() ;
        }
    }

    debug("make_maze_list(): done.") ;

    glEndList() ;
}

/** Draw breadcrumbs.
 */
void draw_visited_cells() {
    debug("draw_visited_cells()") ;

    glMatrixMode(GL_MODELVIEW) ;

    list356_itr_t* itr = lst_iterator(visited) ;
    while (lst_has_next(itr)) {
        cell_t* cell = lst_next(itr) ;
        glPushMatrix() ;
        glTranslatef(cell->c, cell->r, 0.01) ;
        glScalef(.2, .2, 1.0) ;
        draw_floor_tile(&gold) ;
        glPopMatrix() ;
    }
    lst_iterator_free(itr) ;
}

#ifdef DRAW_GRID
void draw_grid() {
    glDisable(GL_LIGHTING) ;

    glBegin(GL_LINES) ;
    for (int r=0; r<=nrows; ++r) {
        glColor3f(0.0, 1.0, 0.0) ;
        glVertex3f(0, r, -.01) ;
        glVertex3f(ncols, r, -.01) ;
        glColor3f(1.0, 0.0, 0.0) ;
        for (int i=1; i<=3; ++i) {
            glVertex3f(0, r+i*.25, -.01) ;
            glVertex3f(ncols, r+i*.25, -.01) ;
        }
    }
    for (int c=0; c<=ncols; ++c) {
        glColor3f(0.0, 1.0, 0.0) ;
        glVertex3f(c, 0, 0) ;
        glVertex3f(c, nrows, 0) ;
        glColor3f(1.0, 0.0, 0.0) ;
        for (int i=1; i<=3; ++i) {
            glVertex3f(c+i*.25, 0, 0) ;
            glVertex3f(c+i*.25, nrows, 0) ;
        }
    }
    glEnd()  ;

    glEnable(GL_LIGHTING) ;
}
#endif

/** Draw a string on the screen.  The string will be drawn in the current
 *  color and at the current raster position.
 */
void draw_string(char* s) {
    for (char *c=s; *c!='\0'; ++c) {
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, *c) ;
    }
}

/** Print the position (distance, theta, and phi) on the screen.
 */
void print_position() {
    glDisable(GL_LIGHTING) ;
    glDisable(GL_DEPTH_TEST) ;
    glColor3f(1.0f, 1.0f, 1.0f) ;

    char* s ;
    glWindowPos2s(10, 30) ;
    asprintf(&s, "Camera position = (%f, %f, %f)", eye_x,
            eye_y, eye_z) ;
    draw_string(s) ;

    glWindowPos2s(10, 10) ;
    asprintf(&s, "Heading = %f", heading) ;
    draw_string(s) ;
    free(s) ;

    glEnable(GL_LIGHTING) ;
    glEnable(GL_DEPTH_TEST) ;
}

/** Handle a display request by clearing the screen, positioning the
 *  light(s), drawing the maze and then drawing the visited cells.
 */
void handle_display() {
    debug("handle_display()") ;

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ) ;

    debug("handle_display(): light.") ;
    glLightfv(GL_LIGHT0, GL_POSITION, light0_pos) ;
    glLightfv(GL_LIGHT1, GL_POSITION, light1_pos) ;
    // glLightfv(GL_LIGHT1, GL_POSITION, light1.position) ;

    debug("handle_display(): maze.") ;
    glCallList(maze_list) ;
    draw_visited_cells() ;

#ifdef DRAW_GRID
    draw_grid() ;
#endif

    print_position() ;

    debug("handle_display(): flush.") ;
    glFlush() ;

    debug("handle_display(): done.") ;
}

//
// NAVIGATION FUNCTIONS.
//

/** Convert degrees to radians.
 *   
 *  @param deg a value in degrees.
 *
 *  @return the result of converting <code>deg</code> from degrees to radians.
 */
float deg2rad(float deg) {
    return deg*M_PI/180 ;
}

/** Check whether there would be a collision between the player and
 *  a wall.
 *
 *  @param x the x-coordinate of the player.
 *  @param y the y-coordinate of the player.
 *
 *  @return:  <code>true</code> if the bounding sphere around (x, y)
 *      intersects a maze wall, <code>false</code> otherwise.
 */
bool collision(float x, float y) {
    debug("collision(%f, %f)", x, y) ;

    // Which cell is the player located in?
    cell_t* c = get_cell(maze, lround(y), lround(x)) ;
    debug("\tin cell (%d, %d)", c->c, c->r) ;

    // Check for a wall in each direction; if there is one, check whether
    // our bounding sphere intersects it.

    if (has_wall(maze, c, NORTH) && (y + BOUNDING_RADIUS > c->r+.5-WALL_WIDTH2))
        return true ;
    if (has_wall(maze, c, EAST) && (x + BOUNDING_RADIUS > c->c+.5-WALL_WIDTH2))
        return true ;
    if (has_wall(maze, c, SOUTH) && (y-BOUNDING_RADIUS < c->r-.5+WALL_WIDTH2))
        return true ;
    if (has_wall(maze, c, WEST) && (x-BOUNDING_RADIUS < c->c-.5+WALL_WIDTH2))
        return true ;
    return false ;
}

/** Move one step either forward or backward, provided that does not result
 *  in a collision with a wall.
 *  
 *  @param dir the direction in which to move; +1 for forward,
 *      -1 for backward.
 */
void move(int dir) {
    float heading_rad = deg2rad(heading) ;
    float new_x = eye_x + dir*STEP_DIST*cos(heading_rad) ;
    float new_y = eye_y + dir*STEP_DIST*sin(heading_rad) ;
    if (!collision(new_x, new_y)) {
        eye_x = new_x ;
        eye_y = new_y ;
    }
    cell_t* cell = get_cell(maze, lround(eye_y), lround(eye_x)) ;
    if (!lst_contains(visited, cell, cell_cmp)) lst_add(visited, cell) ;
}

/** Handle keyboard events:
 *  
 *  - SPACE:  begin/end jump.
 *
 *  Redisplays will be requested from every key event.
 *
 *  @param key the key that was pressed.
 *  @param x the mouse x-position when <code>key</code> was pressed.
 *  @param y the mouse y-position when <code>key</code> was pressed.
 */
void handle_key(unsigned char key, int x, int y) {

    switch (key) {
        case ' ':
            // Jump up to look around.
            if (am_jumping) {
                glPopMatrix() ;
                glutSpecialFunc(handle_special_key) ;
                am_jumping = false ;
            }
            else {
                glMatrixMode(GL_MODELVIEW) ;
                glPushMatrix() ;
                glLoadIdentity() ;
                gluLookAt(eye_x, eye_y, JUMP_HEIGHT,
                        eye_x+3*cos(deg2rad(heading)),
                        eye_y+3*sin(deg2rad(heading)),
                        0,
                        0, 0, 1) ;
                glutSpecialFunc(NULL) ;
                am_jumping = true ;
            }
        default:
            break ;
    }
    glutPostRedisplay() ;
}

/** Handle keyboard events:
 *
 *  - LEFT, RIGHT:  increment/decrement heading angle.
 *  - UP, DOWN:  move forward/backward.
 *
 *  Redisplays will be requested for every key event.
 *
 *  @param key the key that was pressed.
 *  @param x the mouse x-position when <code>key</code> was pressed.
 *  @param y the mouse y-position when <code>key</code> was pressed.
 */
void handle_special_key(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_LEFT:
            heading += HEADING_INCR ;
            if (heading >= 360) heading -= 360 ;
            break ;
        case GLUT_KEY_RIGHT:
            heading -= HEADING_INCR ;
            if (heading < 0) heading += 360 ;
            break ;
        case GLUT_KEY_UP:
            move(1) ;
            break ;
        case GLUT_KEY_DOWN:
            move(-1) ;
            break ;
        default:
            break ;
    }
    set_camera() ;
    glutPostRedisplay() ;

}
